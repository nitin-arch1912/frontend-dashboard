# Hindu College ERP Portal - Setup & Usage Guide

## 📦 What You're Getting

You have received a complete, fully functional Student ERP Portal with 5 main pages:

1. **index.html** - Landing/Home page with feature showcase
2. **login.html** - Student authentication page
3. **signup.html** - New account registration
4. **forgot-password.html** - Password recovery flow
5. **dashboard.html** - Main student dashboard with all modules

## 🚀 Installation Instructions

### Step 1: Download Files
All files have been prepared in the outputs folder. Download:
- index.html
- login.html
- signup.html
- forgot-password.html
- dashboard.html
- README.md

### Step 2: Create Project Folder
```
Create a folder: hindu-college-erp/
Place all HTML files inside this folder
```

### Step 3: Open the Application

#### Option A: Direct Browser Open (Simplest)
1. Open `index.html` in your web browser
2. Click "Login Now" or "Create Account"

#### Option B: Using Local Server (Recommended)
This is better for testing and development.

**Python 3 (Built-in):**
```bash
cd your-project-folder
python -m http.server 8000
# Visit: http://localhost:8000
```

**Node.js - http-server:**
```bash
npm install -g http-server
cd your-project-folder
http-server
# Visit: http://localhost:8080
```

**VS Code - Live Server Extension:**
1. Install "Live Server" extension
2. Right-click on index.html
3. Select "Open with Live Server"

## 🔐 Demo Login Credentials

### Primary Account
**Student ID:** `STU2024001`
**Password:** `demo123`

### Secondary Account
**Student ID:** `STU2024002`
**Password:** `demo123`

**Note:** Demo OTP for password reset is `123456`

## 🎯 Quick Start Tutorial

### 1. Landing Page (index.html)
- Shows college branding and key features
- Navigation buttons to Login and Signup
- Feature cards highlighting system capabilities

**Action:** Click "Login Now" button

### 2. Login Page (login.html)
- Enter Student ID: `STU2024001`
- Enter Password: `demo123`
- Click "Sign In"
- You'll see a loading animation, then redirect to dashboard

**Features to Try:**
- Click the eye icon to show/hide password
- Try invalid credentials to see error message
- Check "Remember me" checkbox

### 3. Signup Page (signup.html)
- Fill in student information
- Select department
- Create password (minimum 6 characters)
- Confirm password match
- Account created and redirected to login

### 4. Forgot Password (forgot-password.html)
- Enter Student ID
- Verify OTP (use: 123456)
- Create new password
- Redirects to login

### 5. Dashboard (dashboard.html)
This is the main application with 9 different sections:

#### Dashboard Section (Default View)
**What you'll see:**
- 4 Metric Cards (CGPA, Attendance, Fees, Courses)
- 4 Interactive Charts (Attendance, Performance, Grades, Comparison)
- Recent Announcements

**Try These:**
- Hover over metric cards for animations
- Look at charts for data visualization
- Read latest announcements

#### My Profile
- Student information display
- Contact details
- Emergency contact
- All information is editable in a real app

**Try:**
- Click on the profile card to see full details
- View student metadata

#### Attendance
- Subject-wise attendance table
- Shows: Classes Held, Attended, Percentage, Status
- Overall attendance progress bar (92%)

**Status Indicators:**
- ✓ Green = Good attendance
- ⚠️ Orange = Low attendance
- ✗ Red = Need improvement

#### Results
- Semester grades and marks
- SGPA and CGPA display
- Subject-wise performance table
- Letter grades (A+, A, B+, etc.)

**View:**
- 6 subjects with marks
- Percentage and grade for each subject

#### Fees Management
- Total fees: ₹1,50,000
- Paid amount: ₹1,45,000
- Pending dues: ₹5,000
- Payment history table
- Transaction details

#### Documents
- Upload button (demo)
- List of uploaded documents
- File download options
- Document types (PDF, Images)

#### AI Assistant
- Interactive chatbot interface
- Try these suggested questions:
  1. "What is my CGPA?" → Shows CGPA info
  2. "What is my attendance?" → Shows attendance percentage
  3. "Do I have pending fees?" → Shows fee status
  4. "What are my exam dates?" → Shows exam schedule
- Type custom questions in the input box

#### Notifications
- Real-time announcement alerts
- Fee payment reminders
- Exam schedules
- Unread notification badge

#### Settings
- Theme selection (Light/Dark mode)
- Notification preferences
- Email notification toggles
- Customizable alerts

## 🎨 Top Navigation Features

**Search Bar:**
- Decorative element, can be extended for search functionality

**Notification Bell:**
- Shows unread count (3 notifications)
- Click to view notification details

**Theme Toggle (🌙):**
- Switches between dark and light modes
- Changes page appearance

**User Profile:**
- Shows student avatar (initials)
- Displays student name
- Can be extended for profile dropdown

## 🖱️ Interactive Elements

### Buttons
- **Primary Buttons:** Blue gradient with hover animation
- **Secondary Buttons:** Outlined style with transparency
- **Loading State:** Spinning animation on submit

### Forms
- Input validation with error messages
- Focus states with color change
- Password toggle visibility
- Real-time form feedback

### Tables
- Hover effects on rows
- Status badges with color coding
- Sortable columns (extendable)
- Responsive table layout

### Cards
- Hover animation (lift effect)
- Border color change on hover
- Icon animations
- Smooth transitions

## 🌈 Theme Customization

### Colors Used
```
Primary Blue:    #0066ff
Secondary Cyan:  #00d4ff
Accent Pink:     #ff006e
Success Green:   #2ed573
Warning Orange:  #ffa502
Danger Red:      #ff4757
Dark Background: #0a0e27
```

### Fonts
- **Headers:** Space Grotesk (bold, modern)
- **Body Text:** Outfit (clean, readable)
- **Fallback:** System fonts

## 📊 Sample Data Included

### Student Profile
- Name: Sneha Sharma
- Student ID: STU2024001
- Department: Computer Science (CSE)
- Year: 3rd Year
- CGPA: 8.5/10.0
- Attendance: 92%

### Academic Data
- 6 Subjects with marks
- Attendance records (80-95%)
- Grade distribution (A+, A, B+)
- Fee payment history

### Announcements
- Mid-semester exam schedule
- Fee payment reminder
- Library timing updates

## 🔧 Customization Tips

### Change Student Name
In dashboard.html, find:
```javascript
document.getElementById('userDisplayName').textContent = 'Your Name';
```

### Change College Name
Search for "Hindu College" and replace with your college name

### Modify Fees Amount
In the Fees section, update the metric values

### Add Your Logo
Replace emoji logos with actual images (example: add image tag instead of 📊)

### Change Color Theme
Edit CSS variables in any HTML file's style section:
```css
:root {
    --primary: #0066ff; /* Change this */
    --secondary: #00d4ff; /* Change this */
}
```

## 🐛 Troubleshooting

### Page doesn't load
- ✓ Ensure all HTML files are in the same folder
- ✓ Use a local server (Python/Node/Live Server)
- ✓ Check browser console (F12) for errors

### Charts not showing
- ✓ Check browser console for JavaScript errors
- ✓ Ensure Chart.js CDN is accessible
- ✓ Try refreshing the page

### Styling looks broken
- ✓ Clear browser cache (Ctrl+Shift+Delete)
- ✓ Try different browser
- ✓ Check internet connection for fonts

### Can't login
- ✓ Use exact credentials: `STU2024001` / `demo123`
- ✓ Check for spaces in input
- ✓ Clear browser localStorage

### Responsive design issues
- ✓ Check browser zoom level (should be 100%)
- ✓ Test on different screen sizes
- ✓ Open developer tools (F12) for debugging

## 📱 Testing on Mobile

### Using Your Computer
1. Open browser DevTools (F12)
2. Click responsive design mode icon
3. Select device (iPhone, iPad, etc.)
4. Test all features

### On Actual Mobile Device
1. Open local server on computer
2. Find computer IP address
3. On mobile, visit: `http://[computer-ip]:8000`
4. Test navigation and features

## 🎓 Advanced Features

### Search Functionality
The search bar is present but currently decorative. To implement:
```javascript
// Add in dashboard.html
const searchInput = document.querySelector('.search-bar input');
searchInput.addEventListener('input', (e) => {
    // Add search logic here
});
```

### Export Features
Add buttons to export:
- PDF report of attendance
- Excel spreadsheet of results
- Certificate generation

### Backend Integration
When ready to add backend:
1. Replace mock data with API calls
2. Use Fetch API or Axios
3. Update authentication flow
4. Store tokens securely

## 📈 Scalability

To extend this application:
1. **Add More Modules** - Create new sections
2. **Implement Backend** - Node.js, Django, or ASP.NET
3. **Database** - MongoDB, MySQL, PostgreSQL
4. **Authentication** - JWT or OAuth
5. **Real-time Updates** - WebSockets
6. **Mobile App** - React Native or Flutter

## 📞 Support & Documentation

### Getting Help
1. Check README.md for complete feature list
2. Review code comments in HTML files
3. Check browser console (F12) for errors
4. Test with demo credentials

### Code Structure
Each HTML file is self-contained with:
- HTML markup
- CSS styling (inline in <style> tag)
- JavaScript functionality (inline in <script> tag)

This allows easy deployment without needing build tools.

## 🚀 Deployment

### Deploy to Free Hosting
1. **Vercel:** Upload files directly
2. **Netlify:** Drag and drop files
3. **GitHub Pages:** Push to repository
4. **Firebase Hosting:** Use CLI tools

### Production Checklist
- [ ] Replace demo data with real information
- [ ] Update college branding and logo
- [ ] Test all features on multiple browsers
- [ ] Optimize images if added
- [ ] Set up proper authentication
- [ ] Enable HTTPS
- [ ] Test on mobile devices
- [ ] Set up error logging
- [ ] Add privacy policy
- [ ] Add terms of service

## 📝 License & Usage

This is a demonstration project created for educational purposes. Feel free to:
- Customize for your college
- Extend with additional features
- Deploy for production use
- Modify styling and branding
- Integrate with backend systems

---

## ✅ Verification Checklist

After setup, verify:
- [ ] All 5 HTML files are in the same directory
- [ ] Can open index.html in browser
- [ ] Login works with `STU2024001` / `demo123`
- [ ] Dashboard loads with all sections
- [ ] Charts render properly
- [ ] Mobile responsive layout works
- [ ] All navigation items clickable
- [ ] Theme toggle works
- [ ] No console errors

---

**🎉 Congratulations! Your Hindu College ERP Portal is ready!**

For questions or updates, refer to the README.md file.

Happy Learning! 🎓
