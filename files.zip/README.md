# Hindu College ERP Portal - Student Dashboard

A fully functional, modern Student ERP (Enterprise Resource Planning) portal with a professional SaaS-style dashboard for managing academic information.

## 🎯 Features

### ✨ Core Modules
- **📊 Dashboard** - View all academic metrics and announcements at a glance
- **👤 Profile** - Access and view student information
- **✅ Attendance** - Track attendance with subject-wise breakdown
- **📈 Results** - View grades, marks, and performance analytics
- **💰 Fees** - Manage fees, view payment history, and pending dues
- **📄 Documents** - Upload and download important academic documents
- **🤖 AI Assistant** - Interactive chatbot for academic queries
- **🔔 Notifications** - Stay updated with announcements and reminders
- **⚙️ Settings** - Customize theme and notification preferences

### 🎨 Design Features
- **Modern Glassmorphism UI** - Frosted glass effects with blur backgrounds
- **Smooth Animations** - Page transitions and micro-interactions
- **Dark/Light Mode** - Toggle between themes
- **Fully Responsive** - Works seamlessly on desktop, tablet, and mobile
- **Interactive Charts** - Chart.js powered analytics with real-time data
- **Professional Typography** - Space Grotesk and Outfit fonts
- **Gradient Accents** - Blue and cyan gradient color scheme

### 📱 Responsive Design
- Desktop: Full-featured experience with sidebar navigation
- Tablet: Optimized layout with collapsible sidebar
- Mobile: Touch-friendly interface with stacked layout

## 📁 File Structure

```
├── index.html                 # Landing page
├── login.html                 # Student login
├── signup.html                # Account registration
├── forgot-password.html       # Password recovery
├── dashboard.html             # Main dashboard
└── README.md                  # Documentation
```

## 🚀 Quick Start

### Option 1: Direct File Access
1. Download all HTML files
2. Open `index.html` in your web browser
3. Navigate to login and use demo credentials

### Option 2: Using a Local Server
```bash
# Using Python 3
python -m http.server 8000

# Using Node.js (http-server)
npx http-server

# Using Live Server (VS Code)
# Install Live Server extension and click "Go Live"
```

Then visit: `http://localhost:8000`

## 🔐 Demo Credentials

**Student Login:**
- Student ID: `STU2024001`
- Password: `demo123`

**Also Available:**
- Student ID: `STU2024002`
- Password: `demo123`

## 🎓 Module Details

### Dashboard
- View key metrics: CGPA, Attendance, Pending Fees, Enrolled Courses
- Interactive charts showing attendance trends and performance
- Latest announcements from the college
- Quick statistics overview

### Attendance
- Subject-wise attendance tracking
- Attendance percentage with visual progress bar
- Attendance status indicators (Present/Absent/Leave)
- Overall attendance summary

### Results
- Semester-wise grade display
- Subject marks and percentages
- SGPA and CGPA display
- Grade distribution visualization

### Fees Management
- Total fees, paid amount, and pending dues
- Payment history with transaction details
- Payment status indicators
- Due date tracking

### Documents
- Upload and download facility
- Document list with file types and sizes
- Quick access to important documents

### AI Assistant
- Suggested questions for quick answers
- Chat interface with common queries
- Answers about CGPA, attendance, fees, and exams
- Real-time chat responses

### Notifications
- Announcement alerts
- Fee reminders
- Exam schedules
- Important updates

## 🎨 Color Scheme

| Element | Color | Hex |
|---------|-------|-----|
| Primary | Blue | #0066ff |
| Secondary | Cyan | #00d4ff |
| Accent | Pink | #ff006e |
| Success | Green | #2ed573 |
| Warning | Orange | #ffa502 |
| Danger | Red | #ff4757 |
| Background | Dark Navy | #0a0e27 |

## 🛠️ Technology Stack

**Frontend:**
- HTML5 - Semantic markup
- CSS3 - Modern styling with gradients and animations
- JavaScript ES6 - Interactive functionality
- Chart.js - Data visualization
- Google Fonts - Professional typography

**Features:**
- LocalStorage for authentication state
- Mock API responses (no backend required)
- Responsive design with CSS Grid and Flexbox
- CSS animations and transitions

## 📊 Data Visualization

### Charts Included
1. **Attendance Trend** - Line chart showing attendance over months
2. **Subject Performance** - Bar chart comparing marks across subjects
3. **Grade Distribution** - Pie/Doughnut chart showing grade breakdown
4. **Result Comparison** - Radar chart comparing semester performance

All charts are interactive and responsive.

## 🔄 Authentication Flow

1. **Landing Page** → Introduction and feature highlights
2. **Signup** → Create new student account
3. **Login** → Authentication with demo credentials
4. **Dashboard** → Full access to all modules
5. **Logout** → Return to login page

## 📱 Navigation

### Sidebar Navigation (Desktop)
- Dashboard, Profile, Attendance, Results, Fees, Documents, AI Assistant, Notifications, Settings, Logout

### Top Navbar
- Search bar, Notifications, Theme toggle, User profile dropdown

## 🎯 User Experience Features

- **Smooth Scrolling** - Animated transitions between sections
- **Loading States** - Button animations during actions
- **Error Messages** - Clear feedback for invalid inputs
- **Success Alerts** - Confirmation messages for actions
- **Hover Effects** - Interactive card and button states
- **Mobile Optimization** - Touch-friendly interfaces

## 🔧 Customization

### Change Colors
Edit the `:root` CSS variables:
```css
:root {
    --primary: #0066ff;
    --secondary: #00d4ff;
    --bg-dark: #0a0e27;
    /* ... other colors */
}
```

### Modify Student Data
Edit the mock data in JavaScript sections:
```javascript
// In dashboard.html - Update student information
document.getElementById('userDisplayName').textContent = 'Your Name';
```

### Add More Subjects/Courses
Update the table rows in respective sections (Attendance, Results, Fees)

## 📈 Performance Features

- Optimized CSS with minimal repaints
- Efficient JavaScript with event delegation
- Cached chart instances
- Lazy loading of animations
- Minimal external dependencies

## 🌐 Browser Compatibility

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🔒 Security Notes

**Important:** This is a frontend-only demo application. In production:
1. Never store passwords in localStorage
2. Implement proper backend authentication
3. Use HTTPS for all communications
4. Validate all user inputs server-side
5. Implement CSRF protection
6. Use secure token-based authentication

## 📝 Future Enhancements

- Backend integration with real API
- User data persistence in database
- Email notifications
- SMS alerts for important updates
- Mobile app version
- Payment gateway integration
- Digital certificate generation
- Course recommendations with AI
- Peer comparison analytics

## 🤝 Contributing

This is a showcase project. Feel free to customize and extend it for your needs.

## 📄 License

This project is created as an educational demonstration. Modify and use as needed.

## 🎓 About

Created for Hindu College of Engineering - Student Portal Demonstration
Build Date: 2024
Version: 1.0.0

---

**Need Help?**
- Check the demo credentials above
- Review the file structure
- Ensure all HTML files are in the same directory
- Use a local server for best experience
- Open browser console for any JavaScript errors

**Enjoy exploring the Student ERP Portal! 🚀**
